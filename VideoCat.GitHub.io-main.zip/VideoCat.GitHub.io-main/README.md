# VideoCat.GitHub.io
# Learn to park a website on GitHub

I will create an index.html file to be used for my website: VideoCat.tech
which I will park here on my GitHub.io site to learn how to make the connections.

I will be learning to attach video and audio files for viewing and downloading.

